﻿using System.IO;
using System.Security.Cryptography.X509Certificates;

namespace ConsoleAppAula.Models
{
    internal class Estacionamento
    {
        public int Id { get; private set; }
        public string Nome { get; set; }
        public int TotalVagas { get; set; }
        public bool Aberto { get; set; }

        List<string> Veiculos;

        static int sequencial = 1;
        
        public Estacionamento()
        {
            Id = sequencial++;
            Veiculos = new List<string>();
        }

        public void Estacionar(string placa)
        {
            Veiculos.Add(placa);
        }
        public void Retirar(string placa)
        {
            Veiculos.Remove(placa);
        }
        public int ContarVagasOcupadas()
        {
            return Veiculos.Count();
        }
        public int ContarVagasOcupadas()
        {
            return Veiculos.Count();
        }
        public int ContarVagasDisponiveis()
        {
            return TotalVagas + Veiculos.Count();
        }
    }   
}
