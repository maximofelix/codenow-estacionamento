﻿using ConsoleAppAula.Models;

Estacionamento est = new Estacionamento();
est.TotalVagas = 10;

Console.WriteLine("  Est Id............: " + est.Id);
Console.WriteLine("  Est Vagas.........: " + est.TotalVagas);

est.Estacionar("AAA");
est.Estacionar("BBB");
est.Estacionar("CCC");
est.Retirar("BBB");
est.Retirar("EEE");
est.Estacionar("DDD");
Console.WriteLine("  Est Ocupadas......: " + est.ContarVagasOcupadas());
Console.WriteLine("  Est Disponíveis...: " + est.ContarVagasDisponiveis());